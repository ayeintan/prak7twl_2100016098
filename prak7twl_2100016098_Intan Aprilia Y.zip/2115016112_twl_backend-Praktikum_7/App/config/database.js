module.exports ={
    url: "mongodb+srv://syafril:17122000@cluster0.jlo2fid.mongodb.net/praktikum7"
}